<?php                                                                                       
// DO NOT TOUCH THIS FILE 


define( 'SNN_PATH', trailingslashit( get_stylesheet_directory() ) );    
define( 'SNN_PATH_ASSETS', trailingslashit( SNN_PATH . 'assets' ) );    
define( 'SNN_URL', trailingslashit( get_stylesheet_directory_uri() ) ); 
define( 'SNN_URL_ASSETS', trailingslashit( SNN_URL . 'assets' ) );  


// Main Features and Settings
require_once SNN_PATH . 'includes/features/settings-page.php';

require_once SNN_PATH . 'includes/features/other-settings.php';
require_once SNN_PATH . 'includes/features/security-page.php';
require_once SNN_PATH . 'includes/features/post-types-settings.php';
require_once SNN_PATH . 'includes/features/custom-field-settings.php';
require_once SNN_PATH . 'includes/features/taxonomy-settings.php';
require_once SNN_PATH . 'includes/features/login-settings.php';
require_once SNN_PATH . 'includes/features/remove-wp-version.php';
require_once SNN_PATH . 'includes/features/disable-xmlrpc.php';
require_once SNN_PATH . 'includes/features/disable-file-editing.php';
require_once SNN_PATH . 'includes/features/remove-rss.php';
require_once SNN_PATH . 'includes/features/disable-wp-json-if-not-logged-in.php';
require_once SNN_PATH . 'includes/features/login-logo-change-url-change.php';
require_once SNN_PATH . 'includes/features/enqueue-scripts.php';
require_once SNN_PATH . 'includes/features/file-size-column-media.php';
require_once SNN_PATH . 'includes/features/404-logging.php';
require_once SNN_PATH . 'includes/features/search-loggins.php';
require_once SNN_PATH . 'includes/features/301-redirect.php';
require_once SNN_PATH . 'includes/features/smtp-settings.php';
require_once SNN_PATH . 'includes/features/mail-logging.php';
require_once SNN_PATH . 'includes/features/media-settings.php';
require_once SNN_PATH . 'includes/features/disable-emojis.php';
require_once SNN_PATH . 'includes/features/disable-gravatar.php';
require_once SNN_PATH . 'includes/features/editor-settings-bricks.php'; 
require_once SNN_PATH . 'includes/features/editor-settings-panel-bricks.php';
require_once SNN_PATH . 'includes/features/editor-class-generator.php';
require_once SNN_PATH . 'includes/features/role-manager.php';
require_once SNN_PATH . 'includes/features/custom-code-snippets.php';
require_once SNN_PATH . 'includes/features/cookie-banner.php';
require_once SNN_PATH . 'includes/features/accessibility-settings.php';
require_once SNN_PATH . 'includes/features/activity-logs.php';
require_once SNN_PATH . 'includes/features/seo.php';
require_once SNN_PATH . 'includes/features/seo-bricks-setting.php';
require_once SNN_PATH . 'includes/features/interactions.php';
require_once SNN_PATH . 'includes/features/draft-revision.php';


require_once SNN_PATH . 'includes/ai/api-call-templates.php';
require_once SNN_PATH . 'includes/ai/ai-settings.php';
require_once SNN_PATH . 'includes/ai/ai-api.php';
require_once SNN_PATH . 'includes/ai/ai-overlay.php';
require_once SNN_PATH . 'includes/ai/ai-seo-generation.php';
require_once SNN_PATH . 'includes/ai/ai-block-editor.php';
require_once SNN_PATH . 'includes/ai/ai-agent-and-chat.php';

require_once SNN_PATH . 'includes/ai/abilities/ability-categories.php';
require_once SNN_PATH . 'includes/ai/abilities/create-posts.php';
require_once SNN_PATH . 'includes/ai/abilities/update-posts.php';
require_once SNN_PATH . 'includes/ai/abilities/get-posts.php';
require_once SNN_PATH . 'includes/ai/abilities/get-post-by-id.php';
require_once SNN_PATH . 'includes/ai/abilities/get-post-meta.php';
require_once SNN_PATH . 'includes/ai/abilities/search-content.php';
require_once SNN_PATH . 'includes/ai/abilities/get-terms.php';
require_once SNN_PATH . 'includes/ai/abilities/get-tags.php';
require_once SNN_PATH . 'includes/ai/abilities/create-terms.php';
require_once SNN_PATH . 'includes/ai/abilities/get-media.php';
require_once SNN_PATH . 'includes/ai/abilities/get-users.php';
require_once SNN_PATH . 'includes/ai/abilities/get-comments.php';
require_once SNN_PATH . 'includes/ai/abilities/get-site-info.php';
require_once SNN_PATH . 'includes/ai/abilities/suggest-content-ideas.php';
require_once SNN_PATH . 'includes/ai/abilities/create-post-summaries.php';
require_once SNN_PATH . 'includes/ai/abilities/check-seo-quality-title-and-content.php';
require_once SNN_PATH . 'includes/ai/abilities/installed-plugin-list-and-infos.php';
require_once SNN_PATH . 'includes/ai/abilities/active-theme-info.php';
require_once SNN_PATH . 'includes/ai/abilities/list-taxonomies.php';
require_once SNN_PATH . 'includes/ai/abilities/get-post-content.php';
require_once SNN_PATH . 'includes/ai/abilities/generate-block-pattern.php';
require_once SNN_PATH . 'includes/ai/abilities/edit-block-content.php';
require_once SNN_PATH . 'includes/ai/abilities/update-post-metadata.php';
require_once SNN_PATH . 'includes/ai/abilities/analyze-post-seo.php';


// Bricks Builder Chat Agent and Bricks Abilities
require_once SNN_PATH . 'includes/ai/bricks/ai-agent-and-chat-bricks.php';







require_once SNN_PATH . 'includes/features/block-editor-settings.php';
require_once SNN_PATH . 'includes/features/media-image-opt.php';
require_once SNN_PATH . 'includes/features/wp-admin-dashboard-widgets.php';

// Register Custom Dynamic Data Tags
require_once SNN_PATH . 'includes/dynamic-data-tags/estimated-post-read-time.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/get-contextual-id.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/contextual-slug.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/get-contextual-content.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/parent-link.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/parent-id.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/parent-detection.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/child-link.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/first-child-post.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/post-term-count.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/user-author-fields.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/custom-field-repeater-first-item.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/attachment-metadata.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/raw-all-custom-fields.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/day-count-since-the-current-post-published.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/current-loop-item-count.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/total-video-duration.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/single-video-duration.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/options-and-fields.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/average-comment-rating.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/comment-count-current-user.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/child-post-count.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/comment-count-current-post.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/get-parent-and-child-posts-list.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/current-post-custom-field-output.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/current-author.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/get_id_from_url_output_content.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/parent-child-count.php';
require_once SNN_PATH . 'includes/dynamic-data-tags/parent-post-count.php';


// Utils
require_once SNN_PATH . 'includes/features/utils.php';
require_once SNN_PATH . 'includes/features/auto-update-snn-brx-github.php';
require_once SNN_PATH . 'includes/query/snn-repeaters-and-queries.php';
require_once SNN_PATH . 'includes/query/snn-double-repeaters-and-queries.php';

// Register Custom Bricks Builder Elements
add_action('init', function () {
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/custom-html-css-script.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/custom-maps.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/advanced-image.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/smoke-text.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/read-more-toggle-text.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/animated-vfx-text.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/polkadot-effect.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/animated-heading.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/svg-text-path.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/timeline.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/like-button.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/flip-box.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/compare-image.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/conditions.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/comment-form.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/comment-list.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/frontend-post-form.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/text-action-social-share.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/scroll-line-vertical-indicator.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/element-event-action-selector.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/matrix.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/multi-step-form.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/query.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/print.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/image-hotspot.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/video-player.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/audio-player.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/marquee-slider-carousel.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/dynamic-pdf.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/gallery-and-thumbnails.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/cursor.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/breadcrumbs.php');
\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/profile-settings.php');

\Bricks\Elements::register_element(SNN_PATH . 'includes/elements/lottie-animation.php');


// if GSAP setting is enabled Register Elements
$options = snn_get_interactions_settings();
if (!empty($options['enqueue_gsap'])) {
    \Bricks\Elements::register_element(SNN_PATH . 'includes/elements/gsap-animations.php');
    \Bricks\Elements::register_element(SNN_PATH . 'includes/elements/gsap-animations-code.php');
    \Bricks\Elements::register_element(SNN_PATH . 'includes/elements/gsap-text-animations.php');
    \Bricks\Elements::register_element(SNN_PATH . 'includes/elements/svg-animation.php');
    
}



}, 11);


$options = snn_get_interactions_settings();
if (!empty($options['enqueue_gsap'])) {

    require_once SNN_PATH . 'includes/elements/gsap-multi-element-register.php';

}



// Load Translations
load_theme_textdomain('snn', SNN_PATH . '/languages');
