<?php 
// The Page for Interactions and Animations Settings
function snn_add_interactions_page() {
    add_submenu_page(
        'snn-settings',
        __('Interactions', 'snn'),
        __('Interactions', 'snn'),
        'manage_options',
        'snn-interactions',
        'snn_render_interactions_page'
    );
}
add_action('admin_menu', 'snn_add_interactions_page');

function snn_enqueue_interactions_admin_scripts($hook) {
    if (!isset($_GET['page']) || $_GET['page'] !== 'snn-interactions') {
        return;
    }
    wp_enqueue_media();
}
add_action('admin_enqueue_scripts', 'snn_enqueue_interactions_admin_scripts');

function snn_render_interactions_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Interactions & Animations', 'snn'); ?></h1>
        <form method="post" action="options.php">
            <?php
                settings_fields('snn_interactions_settings_group');
                do_settings_sections('snn-interactions');
                submit_button();
            ?>
        </form>
    </div>
    <?php
}

function snn_register_interactions_settings() {
    register_setting(
        'snn_interactions_settings_group',
        'snn_interactions_settings',
        'snn_sanitize_interactions_settings'
    );

    add_settings_section(
        'snn_interactions_section',
        __('Animation Settings', 'snn'),
        'snn_interactions_section_callback',
        'snn-interactions'
    );

    add_settings_field(
        'enqueue_gsap',
        __('Enable GSAP and GSAP Elements', 'snn'),
        'snn_enqueue_gsap_callback',
        'snn-interactions',
        'snn_interactions_section'
    );

    add_settings_field(
        'enable_lenis',
        __('Enable Lenis Smooth Scroll', 'snn'),
        'snn_enable_lenis_callback',
        'snn-interactions',
        'snn_interactions_section'
    );

    add_settings_field(
        'enable_page_transitions',
        __('Enable Page Transitions', 'snn'),
        'snn_enable_page_transitions_callback',
        'snn-interactions',
        'snn_interactions_section'
    );
}
add_action('admin_init', 'snn_register_interactions_settings');

function snn_sanitize_interactions_settings($input) {
    $sanitized = array();

    // GSAP settings
    $sanitized['enqueue_gsap'] = isset($input['enqueue_gsap']) && $input['enqueue_gsap'] ? 1 : 0;

    // Lenis settings
    $sanitized['enable_lenis'] = isset($input['enable_lenis']) && $input['enable_lenis'] ? 1 : 0;
    $sanitized['lenis_autoRaf'] = isset($input['lenis_autoRaf']) && $input['lenis_autoRaf'] ? 1 : 0;
    $sanitized['lenis_smoothWheel'] = isset($input['lenis_smoothWheel']) && $input['lenis_smoothWheel'] ? 1 : 0;
    $sanitized['lenis_syncTouch'] = isset($input['lenis_syncTouch']) && $input['lenis_syncTouch'] ? 1 : 0;
    $sanitized['lenis_infinite'] = isset($input['lenis_infinite']) && $input['lenis_infinite'] ? 1 : 0;
    $sanitized['lenis_overscroll'] = isset($input['lenis_overscroll']) && $input['lenis_overscroll'] ? 1 : 0;

    // Lenis numeric settings
    $sanitized['lenis_duration'] = isset($input['lenis_duration']) ? floatval($input['lenis_duration']) : 0.7;
    $sanitized['lenis_lerp'] = isset($input['lenis_lerp']) ? floatval($input['lenis_lerp']) : 0.15;
    $sanitized['lenis_wheelMultiplier'] = isset($input['lenis_wheelMultiplier']) ? floatval($input['lenis_wheelMultiplier']) : 1;
    $sanitized['lenis_syncTouchLerp'] = isset($input['lenis_syncTouchLerp']) ? floatval($input['lenis_syncTouchLerp']) : 0.075;
    $sanitized['lenis_touchMultiplier'] = isset($input['lenis_touchMultiplier']) ? floatval($input['lenis_touchMultiplier']) : 1;
    $sanitized['lenis_touchInertiaExponent'] = isset($input['lenis_touchInertiaExponent']) ? floatval($input['lenis_touchInertiaExponent']) : 1.7;

    // Lenis select settings
    $sanitized['lenis_orientation'] = isset($input['lenis_orientation']) ? sanitize_text_field($input['lenis_orientation']) : 'vertical';
    $sanitized['lenis_gestureOrientation'] = isset($input['lenis_gestureOrientation']) ? sanitize_text_field($input['lenis_gestureOrientation']) : 'vertical';
    $sanitized['lenis_easing'] = isset($input['lenis_easing']) ? sanitize_text_field($input['lenis_easing']) : 'default';

    // Page Transitions settings
    $sanitized['enable_page_transitions'] = isset($input['enable_page_transitions']) && $input['enable_page_transitions'] ? 1 : 0;
    $sanitized['page_transition_type'] = isset($input['page_transition_type']) ? sanitize_text_field($input['page_transition_type']) : 'wipe-down';
    $sanitized['page_transition_duration'] = isset($input['page_transition_duration']) ? floatval($input['page_transition_duration']) : 0.5;

    // Page Transition Selectors
    $sanitized['page_transition_header_selector'] = isset($input['page_transition_header_selector']) ? sanitize_text_field($input['page_transition_header_selector']) : 'header';
    $sanitized['page_transition_main_selector'] = isset($input['page_transition_main_selector']) ? sanitize_text_field($input['page_transition_main_selector']) : 'main, article, #brx-content';
    $sanitized['page_transition_footer_selector'] = isset($input['page_transition_footer_selector']) ? sanitize_text_field($input['page_transition_footer_selector']) : 'footer';
    $sanitized['page_transition_update_mode'] = isset($input['page_transition_update_mode']) ? sanitize_text_field($input['page_transition_update_mode']) : 'smart';

    return $sanitized;
}

function snn_interactions_section_callback() {
    echo '<p>' . esc_html__( 'Configure animation and interaction settings for your site below.', 'snn' ) . '</p>';
}

/**
 * Get interactions settings with backward compatibility.
 * Checks new location first, falls back to old location if needed.
 *
 * @return array The interactions settings
 */
function snn_get_interactions_settings() {
    $new_settings = get_option('snn_interactions_settings');
    $old_settings = get_option('snn_other_settings');

    // If new settings exist and have at least one interactions-related key, use them
    if ($new_settings && (
        isset($new_settings['enqueue_gsap']) ||
        isset($new_settings['enable_lenis']) ||
        isset($new_settings['enable_page_transitions'])
    )) {
        return $new_settings;
    }

    // Fall back to old settings for backward compatibility
    if ($old_settings) {
        return $old_settings;
    }

    // Return empty array if neither exists
    return array();
}

/**
 * One-time migration of interactions settings from old location to new location.
 * This function runs once and migrates existing settings.
 */
function snn_migrate_interactions_settings() {
    // Check if migration has already been done
    if (get_option('snn_interactions_migrated')) {
        return;
    }

    $old_settings = get_option('snn_other_settings');
    $new_settings = get_option('snn_interactions_settings');

    // Only migrate if old settings exist and new settings don't
    if ($old_settings && !$new_settings) {
        $interactions_keys = array(
            'enqueue_gsap',
            'enable_lenis',
            'lenis_autoRaf',
            'lenis_duration',
            'lenis_lerp',
            'lenis_wheelMultiplier',
            'lenis_smoothWheel',
            'lenis_orientation',
            'lenis_gestureOrientation',
            'lenis_syncTouch',
            'lenis_syncTouchLerp',
            'lenis_touchMultiplier',
            'lenis_touchInertiaExponent',
            'lenis_infinite',
            'lenis_overscroll',
            'lenis_easing',
            'enable_page_transitions',
            'page_transition_type',
            'page_transition_duration',
            'page_transition_header_selector',
            'page_transition_main_selector',
            'page_transition_footer_selector',
            'page_transition_update_mode'
        );

        $migrated_settings = array();
        foreach ($interactions_keys as $key) {
            if (isset($old_settings[$key])) {
                $migrated_settings[$key] = $old_settings[$key];
            }
        }

        // Save migrated settings to new location if any were found
        if (!empty($migrated_settings)) {
            update_option('snn_interactions_settings', $migrated_settings);

            // Remove interactions settings from old location
            foreach ($interactions_keys as $key) {
                unset($old_settings[$key]);
            }
            update_option('snn_other_settings', $old_settings);
        }
    }

    // Mark migration as complete
    update_option('snn_interactions_migrated', true);
}
add_action('admin_init', 'snn_migrate_interactions_settings');

function snn_enqueue_gsap_callback() {
    $options = snn_get_interactions_settings();
    ?>
    <input type="checkbox" name="snn_interactions_settings[enqueue_gsap]" value="1" <?php checked(1, isset($options['enqueue_gsap']) ? $options['enqueue_gsap'] : 0); ?>>
    <p>
        <?php _e('Enabling this setting will enqueue the GSAP library and its associated scripts on your website.', 'snn'); ?><br>
        <?php _e('GSAP is a powerful JavaScript animation library that allows you to create complex and interactive animations.', 'snn'); ?><br><br>
        - <?php _e('Ability to create GSAP animations with just data-animate attributes.', 'snn'); ?><br>
        - <?php _e('gsap.min.php: The core GSAP library.', 'snn'); ?><br>
        - <?php _e('ScrollTrigger.min.php: A GSAP plugin that enables scroll-based animations.', 'snn'); ?><br>
        - <?php _e('gsap-data-animate.php: A custom script that utilizes GSAP and ScrollTrigger for animating elements based on data attributes.', 'snn'); ?><br>
    </p>
    <?php
}

function snn_enqueue_gsap_scripts() {
    $options = snn_get_interactions_settings();
    if (isset($options['enqueue_gsap']) && $options['enqueue_gsap']) {
        wp_enqueue_script('gsap-js', SNN_URL_ASSETS . 'js/gsap.min.js', array(), null, true);
        wp_enqueue_script('gsap-st-js', SNN_URL_ASSETS . 'js/ScrollTrigger.min.js', array('gsap-js'), null, true);
        wp_enqueue_script('gsap-data-js', SNN_URL_ASSETS . 'js/gsap-data-animate.js?v0.05', array(), null, true);
    }
}
add_action('wp_enqueue_scripts', 'snn_enqueue_gsap_scripts');
add_action('admin_enqueue_scripts', 'snn_enqueue_gsap_scripts');

function snn_enable_lenis_callback() {
    $options = snn_get_interactions_settings();
    $enabled = isset($options['enable_lenis']) ? $options['enable_lenis'] : 0; ?>
    <div class="lenis-settings">
        <input type="checkbox" id="enable_lenis" name="snn_interactions_settings[enable_lenis]" value="1" <?php checked(1, $enabled); ?>> <label for="enable_lenis"><strong><?php _e('Enable Lenis Smooth Scroll', 'snn'); ?></strong></label>
        <p><?php _e('Lenis is a lightweight, robust, and performant smooth scroll library designed for creating smooth scrolling experiences.', 'snn'); ?></p>
        <div class="lenis-config <?php echo $enabled ? '' : 'lenis-disabled'; ?>">
            <h4><?php _e('Basic Settings', 'snn'); ?></h4>
            <div class="lenis-field"><label><input type="checkbox" name="snn_interactions_settings[lenis_autoRaf]" value="1" <?php checked(1, isset($options['lenis_autoRaf']) ? $options['lenis_autoRaf'] : 1); ?>> <?php _e('Auto RAF (Recommended)', 'snn'); ?></label><p class="description"><?php _e('Automatically run requestAnimationFrame loop. Keep this enabled for best performance.', 'snn'); ?></p></div>
            <div class="lenis-field"><label><?php _e('Duration (seconds)', 'snn'); ?>: <input type="number" class="lenis-input-small" step="0.1" min="0.1" max="5" name="snn_interactions_settings[lenis_duration]" value="<?php echo isset($options['lenis_duration']) ? esc_attr($options['lenis_duration']) : '0.7'; ?>"></label><p class="description"><?php _e('Animation duration in seconds. Default: 0.7', 'snn'); ?></p></div>
            <div class="lenis-field"><label><?php _e('Lerp (smoothness)', 'snn'); ?>: <input type="number" class="lenis-input-small" step="0.01" min="0.01" max="1" name="snn_interactions_settings[lenis_lerp]" value="<?php echo isset($options['lenis_lerp']) ? esc_attr($options['lenis_lerp']) : '0.1'; ?>"></label><p class="description"><?php _e('Linear interpolation intensity (0.01 to 1). Lower = smoother. Default: 0.1', 'snn'); ?></p></div>
            <div class="lenis-field"><label><?php _e('Wheel Multiplier', 'snn'); ?>: <input type="number" class="lenis-input-small" step="0.1" min="0.1" max="5" name="snn_interactions_settings[lenis_wheelMultiplier]" value="<?php echo isset($options['lenis_wheelMultiplier']) ? esc_attr($options['lenis_wheelMultiplier']) : '1'; ?>"></label><p class="description"><?php _e('Mouse wheel scroll speed. Default: 1', 'snn'); ?></p></div>
            <div class="lenis-field"><label><input type="checkbox" name="snn_interactions_settings[lenis_smoothWheel]" value="1" <?php checked(1, isset($options['lenis_smoothWheel']) ? $options['lenis_smoothWheel'] : 1); ?>> <?php _e('Smooth Wheel Events', 'snn'); ?></label><p class="description"><?php _e('Smooth the scroll initiated by wheel events. Default: enabled', 'snn'); ?></p></div>
            <details class="lenis-accordion">
                <summary class="lenis-field lenis-summary"><?php _e('Advanced Settings', 'snn'); ?></summary>
                <div class="lenis-accordion-content">
                    <div class="lenis-field"><label><?php _e('Orientation', 'snn'); ?>: <select name="snn_interactions_settings[lenis_orientation]" class="lenis-select"><option value="vertical" <?php selected(isset($options['lenis_orientation']) ? $options['lenis_orientation'] : 'vertical', 'vertical'); ?>>Vertical</option><option value="horizontal" <?php selected(isset($options['lenis_orientation']) ? $options['lenis_orientation'] : 'vertical', 'horizontal'); ?>>Horizontal</option></select></label><p class="description"><?php _e('Scrolling orientation. Default: vertical', 'snn'); ?></p></div>
                    <div class="lenis-field"><label><?php _e('Gesture Orientation', 'snn'); ?>: <select name="snn_interactions_settings[lenis_gestureOrientation]" class="lenis-select"><option value="vertical" <?php selected(isset($options['lenis_gestureOrientation']) ? $options['lenis_gestureOrientation'] : 'vertical', 'vertical'); ?>>Vertical</option><option value="horizontal" <?php selected(isset($options['lenis_gestureOrientation']) ? $options['lenis_gestureOrientation'] : 'vertical', 'horizontal'); ?>>Horizontal</option><option value="both" <?php selected(isset($options['lenis_gestureOrientation']) ? $options['lenis_gestureOrientation'] : 'vertical', 'both'); ?>>Both</option></select></label><p class="description"><?php _e('Touch gesture orientation. Default: vertical', 'snn'); ?></p></div>
                    <div class="lenis-field"><label><input type="checkbox" name="snn_interactions_settings[lenis_syncTouch]" value="1" <?php checked(1, isset($options['lenis_syncTouch']) ? $options['lenis_syncTouch'] : 0); ?>> <?php _e('Sync Touch', 'snn'); ?></label><p class="description"><?php _e('Mimic touch device scroll (can be unstable on iOS<16). Default: disabled', 'snn'); ?></p></div>
                    <div class="lenis-field"><label><?php _e('Sync Touch Lerp', 'snn'); ?>: <input type="number" class="lenis-input-small" step="0.001" min="0.001" max="1" name="snn_interactions_settings[lenis_syncTouchLerp]" value="<?php echo isset($options['lenis_syncTouchLerp']) ? esc_attr($options['lenis_syncTouchLerp']) : '0.075'; ?>"></label><p class="description"><?php _e('Lerp applied during syncTouch inertia. Default: 0.075', 'snn'); ?></p></div>
                    <div class="lenis-field"><label><?php _e('Touch Multiplier', 'snn'); ?>: <input type="number" class="lenis-input-small" step="0.1" min="0.1" max="5" name="snn_interactions_settings[lenis_touchMultiplier]" value="<?php echo isset($options['lenis_touchMultiplier']) ? esc_attr($options['lenis_touchMultiplier']) : '1'; ?>"></label><p class="description"><?php _e('Touch scroll speed multiplier. Default: 1', 'snn'); ?></p></div>
                    <div class="lenis-field"><label><?php _e('Touch Inertia Exponent', 'snn'); ?>: <input type="number" class="lenis-input-small" step="0.1" min="0.1" max="5" name="snn_interactions_settings[lenis_touchInertiaExponent]" value="<?php echo isset($options['lenis_touchInertiaExponent']) ? esc_attr($options['lenis_touchInertiaExponent']) : '1.7'; ?>"></label><p class="description"><?php _e('Strength of syncTouch inertia. Default: 1.7', 'snn'); ?></p></div>
                    <div class="lenis-field"><label><input type="checkbox" name="snn_interactions_settings[lenis_infinite]" value="1" <?php checked(1, isset($options['lenis_infinite']) ? $options['lenis_infinite'] : 0); ?>> <?php _e('Infinite Scroll', 'snn'); ?></label><p class="description"><?php _e('Enable infinite scrolling. Requires syncTouch on touch devices. Default: disabled', 'snn'); ?></p></div>
                    <div class="lenis-field"><label><input type="checkbox" name="snn_interactions_settings[lenis_overscroll]" value="1" <?php checked(1, isset($options['lenis_overscroll']) ? $options['lenis_overscroll'] : 1); ?>> <?php _e('Overscroll', 'snn'); ?></label><p class="description"><?php _e('Similar to CSS overscroll-behavior. Default: enabled', 'snn'); ?></p></div>
                    <div class="lenis-field"><label><?php _e('Easing Function', 'snn'); ?>: <select name="snn_interactions_settings[lenis_easing]" class="lenis-select"><option value="default" <?php selected(isset($options['lenis_easing']) ? $options['lenis_easing'] : 'default', 'default'); ?>>Default (Custom)</option><option value="linear" <?php selected(isset($options['lenis_easing']) ? $options['lenis_easing'] : 'default', 'linear'); ?>>Linear</option><option value="easeInQuad" <?php selected(isset($options['lenis_easing']) ? $options['lenis_easing'] : 'default', 'easeInQuad'); ?>>Ease In Quad</option><option value="easeOutQuad" <?php selected(isset($options['lenis_easing']) ? $options['lenis_easing'] : 'default', 'easeOutQuad'); ?>>Ease Out Quad</option><option value="easeInOutQuad" <?php selected(isset($options['lenis_easing']) ? $options['lenis_easing'] : 'default', 'easeInOutQuad'); ?>>Ease In Out Quad</option><option value="easeInCubic" <?php selected(isset($options['lenis_easing']) ? $options['lenis_easing'] : 'default', 'easeInCubic'); ?>>Ease In Cubic</option><option value="easeOutCubic" <?php selected(isset($options['lenis_easing']) ? $options['lenis_easing'] : 'default', 'easeOutCubic'); ?>>Ease Out Cubic</option><option value="easeInOutCubic" <?php selected(isset($options['lenis_easing']) ? $options['lenis_easing'] : 'default', 'easeInOutCubic'); ?>>Ease In Out Cubic</option></select></label><p class="description"><?php _e('Easing function for scroll animation. Default: custom exponential', 'snn'); ?></p></div>
                </div>
            </details>
        </div>
        <style>.lenis-config{margin-top:20px}.lenis-disabled{opacity:0.5;pointer-events:none}.lenis-field{margin-bottom:5px}.lenis-input-small{width:80px}.lenis-select{margin-left:10px}.lenis-accordion{border:1px solid #ddd;padding:;border-radius:4px}.lenis-summary{cursor:pointer;font-weight:bold;background:#f0f0f1;padding:10px;border-radius:3px}.lenis-accordion[open] .lenis-summary{margin-bottom:5px}.lenis-accordion-content{margin-top:15px}.lenis-settings label{display:inline-block}.lenis-settings .description{font-size:13px;color:#666}</style>
        <script>document.addEventListener('DOMContentLoaded', function() { const enableCheckbox = document.getElementById('enable_lenis'); const configDiv = document.querySelector('.lenis-config'); if (enableCheckbox && configDiv) { enableCheckbox.addEventListener('change', function() { if (this.checked) { configDiv.classList.remove('lenis-disabled'); } else { configDiv.classList.add('lenis-disabled'); } }); } });</script>
    </div>
<?php }

function snn_enable_page_transitions_callback() {
    $options = snn_get_interactions_settings();
    $enabled = isset($options['enable_page_transitions']) ? $options['enable_page_transitions'] : 0;
    $duration = isset($options['page_transition_duration']) ? $options['page_transition_duration'] : 0.5;
    ?>
    <div class="page-transitions-settings">
        <input type="checkbox" id="enable_page_transitions" name="snn_interactions_settings[enable_page_transitions]" value="1" <?php checked(1, $enabled); ?>> <label for="enable_page_transitions"><strong><?php _e('Enable Page Transitions with View Transition API', 'snn'); ?></strong></label>
        <p style="max-width:800px"><?php _e('The View Transition API provides a mechanism for easily creating animated transitions between different website pages. It allows you to create seamless visual transitions when navigating between pages, improving the user experience.', 'snn'); ?></p>
        <p><?php _e('Learn more:', 'snn'); ?> <a href="https://developer.mozilla.org/en-US/docs/Web/API/View_Transitions_API" target="_blank">View Transitions API - MDN Web Docs</a></p>
        <div class="page-transitions-config <?php echo $enabled ? '' : 'transitions-disabled'; ?>">
            <h4><?php _e('Transition Settings', 'snn'); ?></h4>
            <div class="transitions-field">
                <label><?php _e('Transition Type', 'snn'); ?>:
                    <select name="snn_interactions_settings[page_transition_type]" class="transitions-select">
                        <option value="wipe-down" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'wipe-down'); ?>><?php _e('Wipe Down (Top to Bottom)', 'snn'); ?></option>
                        <option value="wipe-down-soft" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'wipe-down-soft'); ?>><?php _e('Wipe Down Soft Edge (Fade Leading Edge)', 'snn'); ?></option>
                        <option value="wipe-up" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'wipe-up'); ?>><?php _e('Wipe Up (Bottom to Top)', 'snn'); ?></option>
                        <option value="wipe-left" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'wipe-left'); ?>><?php _e('Wipe Left (Right to Left)', 'snn'); ?></option>
                        <option value="wipe-right" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'wipe-right'); ?>><?php _e('Wipe Right (Left to Right)', 'snn'); ?></option>
                        <option value="perspective-flip" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'perspective-flip'); ?>><?php _e('3D Perspective Flip', 'snn'); ?></option>
                        <option value="mosaic-squares" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'mosaic-squares'); ?>><?php _e('Mosaic Grid Reveal', 'snn'); ?></option>
                        <option value="halftone-dots" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'halftone-dots'); ?>><?php _e('Halftone Dots', 'snn'); ?></option>
                        <option value="vertical-shutters" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'vertical-shutters'); ?>><?php _e('Vertical Shutters', 'snn'); ?></option>
                        <option value="horizontal-shutters" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'horizontal-shutters'); ?>><?php _e('Horizontal Shutters', 'snn'); ?></option>
                        <option value="diamond-grid" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'diamond-grid'); ?>><?php _e('Diamond Grid', 'snn'); ?></option>
                        <option value="iris-circle" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'iris-circle'); ?>><?php _e('Iris Circle', 'snn'); ?></option>
                        <option value="diagonal-slashes" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'diagonal-slashes'); ?>><?php _e('Diagonal Slashes', 'snn'); ?></option>
                        <option value="fade" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'fade'); ?>><?php _e('Fade in and Fade out', 'snn'); ?></option>
                        <option value="ink-spread" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'ink-spread'); ?>><?php _e('Ink Spread (Rorschach)', 'snn'); ?></option>
                        <option value="camera-aperture" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'camera-aperture'); ?>><?php _e('Camera Aperture (Spiral)', 'snn'); ?></option>
                        <option value="broken-glass" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'broken-glass'); ?>><?php _e('Broken Glass (Polygons)', 'snn'); ?></option>
                        <option value="pixel-dither" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'pixel-dither'); ?>><?php _e('Pixel Dither (Dissolve)', 'snn'); ?></option>
                        <option value="radial-wipe" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'radial-wipe'); ?>><?php _e('Radial Wipe (Clock Sweep)', 'snn'); ?></option>
                        <option value="hexagon-grid" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'hexagon-grid'); ?>><?php _e('Hexagon Grid', 'snn'); ?></option>
                        <option value="zoom-scale" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'zoom-scale'); ?>><?php _e('Zoom Out Scale', 'snn'); ?></option>
                        <option value="zoom-in-scale" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'zoom-in-scale'); ?>><?php _e('Zoom In Scale', 'snn'); ?></option>
                        <option value="slide-push" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'slide-push'); ?>><?php _e('Slide Push (Carousel)', 'snn'); ?></option>
                        <option value="slide-over" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'slide-over'); ?>><?php _e('Slide Over Stack (iOS Style)', 'snn'); ?></option>
                        <option value="random-mosaic-peel" <?php selected(isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down', 'random-mosaic-peel'); ?>><?php _e('Random Mosaic Peel (Staggered Tiles)', 'snn'); ?></option>
                    </select>
                </label>
                <p class="description"><?php _e('Select the type of transition effect to use when navigating between pages. Default: Wipe Down', 'snn'); ?></p>
            </div>

            <div class="transitions-field">
                <label><?php _e('Transition Duration (seconds)', 'snn'); ?>:</label>
                <input type="number" name="snn_interactions_settings[page_transition_duration]" value="<?php echo esc_attr($duration); ?>" class="transitions-duration-input" step="0.1" min="0.5" max="5">
                <p class="description"><?php _e('Duration of the transition effect in seconds. Default: 0.5s', 'snn'); ?></p>
            </div>

            <details class="transitions-accordion">
                <summary class="transitions-summary"><?php _e('Advanced Settings', 'snn'); ?></summary>
                <div class="transitions-accordion-content">
                    <h4><?php _e('Page Structure Selectors', 'snn'); ?></h4>
                    <p class="description" style="margin-bottom:15px"><?php _e('Define CSS selectors to identify different parts of your page. This helps the transition system properly update content and preserve scripts/assets.', 'snn'); ?></p>

                    <div class="transitions-field">
                        <label><?php _e('Update Mode', 'snn'); ?>:</label>
                        <select name="snn_interactions_settings[page_transition_update_mode]" class="transitions-select">
                            <option value="smart" <?php selected(isset($options['page_transition_update_mode']) ? $options['page_transition_update_mode'] : 'smart', 'smart'); ?>><?php _e('Smart Update (Recommended)', 'snn'); ?></option>
                            <option value="full" <?php selected(isset($options['page_transition_update_mode']) ? $options['page_transition_update_mode'] : 'smart', 'full'); ?>><?php _e('Full Page Replace', 'snn'); ?></option>
                        </select>
                        <p class="description"><?php _e('Smart Update: Only updates main content area while preserving header/footer and scripts. Full Page Replace: Replaces entire page content (may cause asset loading issues). Default: Smart Update', 'snn'); ?></p>
                    </div>

                    <div class="transitions-field">
                        <label><?php _e('Header Selector', 'snn'); ?>:</label>
                        <input type="text" name="snn_interactions_settings[page_transition_header_selector]" value="<?php echo esc_attr(isset($options['page_transition_header_selector']) ? $options['page_transition_header_selector'] : 'header'); ?>" class="regular-text">
                        <p class="description"><?php _e('CSS selector for the global header element. Default: header', 'snn'); ?></p>
                    </div>

                    <div class="transitions-field">
                        <label><?php _e('Main Content Selector', 'snn'); ?>:</label>
                        <input type="text" name="snn_interactions_settings[page_transition_main_selector]" value="<?php echo esc_attr(isset($options['page_transition_main_selector']) ? $options['page_transition_main_selector'] : 'main, article, #brx-content'); ?>" class="regular-text">
                        <p class="description"><?php _e('CSS selector for the main content area. Supports multiple selectors separated by commas. Default: main, article, #brx-content', 'snn'); ?></p>
                    </div>

                    <div class="transitions-field">
                        <label><?php _e('Footer Selector', 'snn'); ?>:</label>
                        <input type="text" name="snn_interactions_settings[page_transition_footer_selector]" value="<?php echo esc_attr(isset($options['page_transition_footer_selector']) ? $options['page_transition_footer_selector'] : 'footer'); ?>" class="regular-text">
                        <p class="description"><?php _e('CSS selector for the global footer element. Default: footer', 'snn'); ?></p>
                    </div>
                </div>
            </details>
        </div>
        <style>
            .page-transitions-config{margin-top:20px}
            .transitions-disabled{opacity:0.5;pointer-events:none}
            .transitions-field{margin-bottom:15px}
            .transitions-select{margin-left:10px;min-width:200px}
            .page-transitions-settings label{display:inline-block}
            .page-transitions-settings .description{font-size:13px;color:#666;margin-top:5px}
            .transitions-duration-input{margin-left:10px;width:80px}
            .transitions-accordion{border:1px solid #ddd;border-radius:4px;margin-top:20px}
            .transitions-summary{cursor:pointer;font-weight:bold;background:#f0f0f1;padding:10px;border-radius:3px;user-select:none}
            .transitions-accordion[open] .transitions-summary{margin-bottom:10px}
            .transitions-accordion-content{padding:15px}
        </style>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var enableCheckbox = document.getElementById('enable_page_transitions');
                var configDiv = document.querySelector('.page-transitions-config');

                if (enableCheckbox && configDiv) {
                    enableCheckbox.addEventListener('change', function() {
                        configDiv.classList.toggle('transitions-disabled', !this.checked);
                    });
                }
            });
        </script>
    </div>
<?php }

function snn_enqueue_lenis_scripts() {
    $options = snn_get_interactions_settings();

    if (isset($options['enable_lenis']) && $options['enable_lenis']) {
        // Enqueue Lenis library
        wp_enqueue_script('lenis-js', SNN_URL_ASSETS . 'js/lenis.min.js', array(), null, true);

        // Get settings with defaults
        $autoRaf = isset($options['lenis_autoRaf']) ? $options['lenis_autoRaf'] : 1;
        $duration = isset($options['lenis_duration']) ? floatval($options['lenis_duration']) : 0.7;
        $lerp = isset($options['lenis_lerp']) ? floatval($options['lenis_lerp']) : 0.1;
        $wheelMultiplier = isset($options['lenis_wheelMultiplier']) ? floatval($options['lenis_wheelMultiplier']) : 1;
        $smoothWheel = isset($options['lenis_smoothWheel']) ? $options['lenis_smoothWheel'] : 1;

        // Advanced settings
        $orientation = isset($options['lenis_orientation']) ? $options['lenis_orientation'] : 'vertical';
        $gestureOrientation = isset($options['lenis_gestureOrientation']) ? $options['lenis_gestureOrientation'] : 'vertical';
        $syncTouch = isset($options['lenis_syncTouch']) ? $options['lenis_syncTouch'] : 0;
        $syncTouchLerp = isset($options['lenis_syncTouchLerp']) ? floatval($options['lenis_syncTouchLerp']) : 0.075;
        $touchMultiplier = isset($options['lenis_touchMultiplier']) ? floatval($options['lenis_touchMultiplier']) : 1;
        $touchInertiaExponent = isset($options['lenis_touchInertiaExponent']) ? floatval($options['lenis_touchInertiaExponent']) : 1.7;
        $infinite = isset($options['lenis_infinite']) ? $options['lenis_infinite'] : 0;
        $overscroll = isset($options['lenis_overscroll']) ? $options['lenis_overscroll'] : 1;
        $easing = isset($options['lenis_easing']) ? $options['lenis_easing'] : 'default';

        // Easing function mapping
        $easingFunctions = array(
            'default' => '(t) => Math.min(1, 1.001 - Math.pow(2, -10 * t))',
            'linear' => '(t) => t',
            'easeInQuad' => '(t) => t * t',
            'easeOutQuad' => '(t) => t * (2 - t)',
            'easeInOutQuad' => '(t) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t',
            'easeInCubic' => '(t) => t * t * t',
            'easeOutCubic' => '(t) => (--t) * t * t + 1',
            'easeInOutCubic' => '(t) => t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1'
        );

        $easingFunction = isset($easingFunctions[$easing]) ? $easingFunctions[$easing] : $easingFunctions['default'];

        // Add performance-optimized CSS
        $inline_css = "
        html.lenis {
            height: auto;
        }
        .lenis.lenis-smooth {
            scroll-behavior: auto !important;
        }
        .lenis.lenis-smooth [data-lenis-prevent] {
            overscroll-behavior: contain;
        }
        /* Performance optimizations to reduce forced reflows */
        html.lenis, body {
            will-change: transform;
            contain: layout style paint;
        }
        /* Optimize off-screen content rendering */
        @supports (content-visibility: auto) {
            body > * {
                content-visibility: auto;
                contain-intrinsic-size: auto 500px;
            }
            header, footer, [data-lenis-prevent] {
                content-visibility: visible;
            }
        }
        /* Force GPU acceleration for smooth scrolling elements */
        .lenis-smooth {
            transform: translateZ(0);
            backface-visibility: hidden;
            perspective: 1000px;
        }
        ";
        wp_add_inline_style('lenis-css', $inline_css);

        // Build Lenis configuration with optimizations
        $inline_script = "
        // Check if URL contains ?bricks=run
        const urlParams = new URLSearchParams(window.location.search);
        if (!urlParams.has('bricks') || urlParams.get('bricks') !== 'run') {
            // Performance optimization: Use passive event listeners
            const supportsPassive = (() => {
                let support = false;
                try {
                    const opts = Object.defineProperty({}, 'passive', {
                        get() { support = true; }
                    });
                    window.addEventListener('test', null, opts);
                    window.removeEventListener('test', null, opts);
                } catch (e) {}
                return support;
            })();

            const lenis = new Lenis({
                autoRaf: " . ($autoRaf ? 'true' : 'false') . ",
                duration: " . $duration . ",
                easing: " . $easingFunction . ",
                lerp: " . $lerp . ",
                wheelMultiplier: " . $wheelMultiplier . ",
                smoothWheel: " . ($smoothWheel ? 'true' : 'false') . ",
                orientation: '" . esc_js($orientation) . "',
                gestureOrientation: '" . esc_js($gestureOrientation) . "',
                syncTouch: " . ($syncTouch ? 'true' : 'false') . ",
                syncTouchLerp: " . $syncTouchLerp . ",
                touchMultiplier: " . $touchMultiplier . ",
                touchInertiaExponent: " . $touchInertiaExponent . ",
                infinite: " . ($infinite ? 'true' : 'false') . ",
                overscroll: " . ($overscroll ? 'true' : 'false') . "
            });

            // Optimize scroll updates to reduce reflows
            // Batch read and write operations
            let ticking = false;
            lenis.on('scroll', (e) => {
                if (!ticking) {
                    window.requestAnimationFrame(() => {
                        // Batch DOM reads/writes here if needed
                        ticking = false;
                    });
                    ticking = true;
                }
            });

            // Store lenis instance globally for debugging/integration
            window.lenis = lenis;
        }
        ";

        wp_add_inline_script('lenis-js', $inline_script);
    }
}
add_action('wp_enqueue_scripts', 'snn_enqueue_lenis_scripts');

/**
 * Helper function to generate consistent mask CSS for SVG-based transitions
 *
 * @param string $encoded_svg Base64 encoded SVG mask
 * @return string CSS rules for the mask-based transition
 */
function snn_generate_mask_css($encoded_svg) {
    return "
    ::view-transition-old(root) { animation: none; z-index: -1; }
    ::view-transition-new(root) {
        z-index: 1;
        -webkit-mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
        mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
        -webkit-mask-size: 100% 100%;
        mask-size: 100% 100%;
        -webkit-mask-repeat: no-repeat;
        mask-repeat: no-repeat;
        -webkit-mask-position: center;
        mask-position: center;
        animation: snn-hold var(--snn-transition-duration) linear forwards;
    }
    @keyframes snn-hold { from { opacity: 1; } to { opacity: 1; } }
    ";
}

/**
 * Enqueue View Transition styles and scripts
 */
function snn_enqueue_page_transitions() {
    $options = snn_get_interactions_settings();

    if (isset($options['enable_page_transitions']) && $options['enable_page_transitions']) {
        $transition_type = isset($options['page_transition_type']) ? $options['page_transition_type'] : 'wipe-down';
        $duration        = isset($options['page_transition_duration']) ? floatval($options['page_transition_duration']) : 0.5;

        // Base Settings
        $inline_css = "
        @view-transition { navigation: auto; }
        :root { --snn-transition-duration: " . $duration . "s; }
        /* Ensure distinct stacking context */
        ::view-transition-group(root) { animation-duration: var(--snn-transition-duration); }
        ";

        // Page-to-Page Transitions
        if ($transition_type === 'wipe-down') {
            // Wipe Down: New page wipes IN over the Old page.
            // Old page stays static (no gap created).
            $inline_css .= "
            ::view-transition-old(root) {
                animation: none;
                z-index: -1;
            }
            ::view-transition-new(root) {
                animation: snn-wipe-down var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 1;
                clip-path: inset(0 0 100% 0); /* Start hidden at top */
            }

            @keyframes snn-wipe-down {
                from { clip-path: inset(0 0 100% 0); }
                to { clip-path: inset(0 0 0 0); }
            }
            ";
        } elseif ($transition_type === 'wipe-down-soft') {
            // Wipe Down Soft Edge: same direction as Wipe Down but the leading
            // edge fades in the new page instead of cutting sharply.
            // Uses @property to interpolate a custom property inside mask-image.
            $inline_css .= "
            @property --snn-wipe-y {
                syntax: '<percentage>';
                inherits: false;
                initial-value: -25%;
            }

            ::view-transition-old(root) {
                animation: none;
                z-index: -1;
            }
            ::view-transition-new(root) {
                animation: snn-wipe-down-soft var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 1;
                mask-image: linear-gradient(to bottom, black calc(var(--snn-wipe-y) - 25%), transparent var(--snn-wipe-y));
            }

            @keyframes snn-wipe-down-soft {
                from { --snn-wipe-y: -25%; }
                to   { --snn-wipe-y: 125%; }
            }
            ";
        } elseif ($transition_type === 'wipe-up') {
            // Wipe Up: New page wipes IN from bottom to top.
            $inline_css .= "
            ::view-transition-old(root) {
                animation: none;
                z-index: -1;
            }
            ::view-transition-new(root) {
                animation: snn-wipe-up var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 1;
                clip-path: inset(100% 0 0 0); /* Start hidden at bottom */
            }

            @keyframes snn-wipe-up {
                from { clip-path: inset(100% 0 0 0); }
                to { clip-path: inset(0 0 0 0); }
            }
            ";
        } elseif ($transition_type === 'wipe-left') {
            // Wipe Left: New page wipes IN from right to left.
            $inline_css .= "
            ::view-transition-old(root) {
                animation: none;
                z-index: -1;
            }
            ::view-transition-new(root) {
                animation: snn-wipe-left var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 1;
                clip-path: inset(0 0 0 100%); /* Start hidden at right */
            }

            @keyframes snn-wipe-left {
                from { clip-path: inset(0 0 0 100%); }
                to { clip-path: inset(0 0 0 0); }
            }
            ";
        } elseif ($transition_type === 'wipe-right') {
            // Wipe Right: New page wipes IN from left to right.
            $inline_css .= "
            ::view-transition-old(root) {
                animation: none;
                z-index: -1;
            }
            ::view-transition-new(root) {
                animation: snn-wipe-right var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 1;
                clip-path: inset(0 100% 0 0); /* Start hidden at left */
            }

            @keyframes snn-wipe-right {
                from { clip-path: inset(0 100% 0 0); }
                to { clip-path: inset(0 0 0 0); }
            }
            ";
        } elseif ($transition_type === 'perspective-flip') {
            // 3D Perspective Flip: Old page rotates away in 3D space, new page rotates in.
            $inline_css .= "
            ::view-transition-old(root),
            ::view-transition-new(root) {
                backface-visibility: hidden;
            }

            ::view-transition-old(root) {
                animation: snn-perspective-out var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 1;
            }
            ::view-transition-new(root) {
                animation: snn-perspective-in var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 2;
            }

            @keyframes snn-perspective-out {
                0% {
                    transform: perspective(1000px) rotateY(0deg) scale(1);
                    opacity: 1;
                }
                100% {
                    transform: perspective(1000px) rotateY(-90deg) scale(0.8);
                    opacity: 0;
                }
            }

            @keyframes snn-perspective-in {
                0% {
                    transform: perspective(1000px) rotateY(90deg) scale(0.8);
                    opacity: 0;
                }
                100% {
                    transform: perspective(1000px) rotateY(0deg) scale(1);
                    opacity: 1;
                }
            }
            ";
        } elseif ($transition_type === 'mosaic-squares') {
            // Mosaic Squares: New page reveals through expanding squares
            $size = 10;

            // Generate unique ID to prevent browser caching the finished animation state
            $unique_id = 'snn_sq_' . uniqid();

            // SVG with SMIL animation - squares grow from 0 to full size
            $svg_mask = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                <defs>
                    <pattern id="'.$unique_id.'" x="0" y="0" width="'.$size.'" height="'.$size.'" patternUnits="userSpaceOnUse">
                        <rect x="0" y="0" width="0" height="0" fill="white">
                            <animate attributeName="width" from="0" to="'.$size.'" dur="'.$duration.'s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.4 0 0.2 1" begin="0s" />
                            <animate attributeName="height" from="0" to="'.$size.'" dur="'.$duration.'s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.4 0 0.2 1" begin="0s" />
                        </rect>
                    </pattern>
                </defs>
                <rect x="0" y="0" width="100" height="100" fill="url(#'.$unique_id.')" />
            </svg>';

            // Base64 encoding prevents breaking of # references (bulletproof)
            $encoded_svg = base64_encode($svg_mask);

            $inline_css .= "
            ::view-transition-old(root) {
                animation: none;
                z-index: -1;
            }
            ::view-transition-new(root) {
                z-index: 1;
                -webkit-mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                -webkit-mask-size: cover;
                mask-size: cover;
                -webkit-mask-position: center;
                mask-position: center;
                -webkit-mask-repeat: repeat;
                mask-repeat: repeat;
                animation: snn-hold var(--snn-transition-duration) linear forwards;
            }

            @keyframes snn-hold {
                from { opacity: 1; }
                to { opacity: 1; }
            }
            ";
        } elseif ($transition_type === 'halftone-dots') {
            // Halftone: Circles grow from center until they overlap to fill screen
            $size = 10; // Pattern size
            $unique_id = 'snn_dot_' . uniqid();

            // R expands to approx 7.1 (sqrt(50)) to ensure square is fully covered by circle
            $svg_mask = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                <defs>
                    <pattern id="'.$unique_id.'" x="0" y="0" width="'.$size.'" height="'.$size.'" patternUnits="userSpaceOnUse">
                        <circle cx="'.($size/2).'" cy="'.($size/2).'" r="0" fill="white">
                            <animate attributeName="r" from="0" to="'.($size * 0.8).'" dur="'.$duration.'s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.4 0 0.2 1" begin="0s" />
                        </circle>
                    </pattern>
                </defs>
                <rect x="0" y="0" width="100" height="100" fill="url(#'.$unique_id.')" />
            </svg>';

            $encoded_svg = base64_encode($svg_mask);

            $inline_css .= "
            ::view-transition-old(root) { animation: none; z-index: -1; }
            ::view-transition-new(root) {
                z-index: 1;
                -webkit-mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                -webkit-mask-size: cover;
                mask-size: cover;
                animation: snn-hold var(--snn-transition-duration) linear forwards;
            }
            @keyframes snn-hold { from { opacity: 1; } to { opacity: 1; } }
            ";
        } elseif ($transition_type === 'vertical-shutters') {
            // Shutters: Vertical bars widening
            $count = 10; // Number of shutters
            $width = 100 / $count;
            $unique_id = 'snn_shut_' . uniqid();

            $svg_mask = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                <defs>
                    <pattern id="'.$unique_id.'" x="0" y="0" width="'.$width.'" height="100" patternUnits="userSpaceOnUse">
                        <rect x="0" y="0" width="0" height="100" fill="white">
                             <animate attributeName="width" from="0" to="'.$width.'" dur="'.$duration.'s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.4 0 0.2 1" begin="0s" />
                        </rect>
                    </pattern>
                </defs>
                <rect x="0" y="0" width="100" height="100" fill="url(#'.$unique_id.')" />
            </svg>';

            $encoded_svg = base64_encode($svg_mask);

            $inline_css .= "
            ::view-transition-old(root) { animation: none; z-index: -1; }
            ::view-transition-new(root) {
                z-index: 1;
                -webkit-mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                -webkit-mask-size: cover;
                mask-size: cover;
                animation: snn-hold var(--snn-transition-duration) linear forwards;
            }
            @keyframes snn-hold { from { opacity: 1; } to { opacity: 1; } }
            ";
        } elseif ($transition_type === 'horizontal-shutters') {
            // Horizontal Shutters: Horizontal bars heightening
            $count = 10; // Number of shutters
            $height = 100 / $count;
            $unique_id = 'snn_hshut_' . uniqid();

            $svg_mask = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                <defs>
                    <pattern id="'.$unique_id.'" x="0" y="0" width="100" height="'.$height.'" patternUnits="userSpaceOnUse">
                        <rect x="0" y="0" width="100" height="0" fill="white">
                             <animate attributeName="height" from="0" to="'.$height.'" dur="'.$duration.'s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.4 0 0.2 1" begin="0s" />
                        </rect>
                    </pattern>
                </defs>
                <rect x="0" y="0" width="100" height="100" fill="url(#'.$unique_id.')" />
            </svg>';

            $encoded_svg = base64_encode($svg_mask);

            $inline_css .= "
            ::view-transition-old(root) { animation: none; z-index: -1; }
            ::view-transition-new(root) {
                z-index: 1;
                -webkit-mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                -webkit-mask-size: cover;
                mask-size: cover;
                animation: snn-hold var(--snn-transition-duration) linear forwards;
            }
            @keyframes snn-hold { from { opacity: 1; } to { opacity: 1; } }
            ";
        } elseif ($transition_type === 'diamond-grid') {
            // Diamonds: Rotated rects
            $size = 10;
            $unique_id = 'snn_dia_' . uniqid();

            // Note: We rotate the rect around the center of the pattern cell
            $svg_mask = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                <defs>
                    <pattern id="'.$unique_id.'" x="0" y="0" width="'.$size.'" height="'.$size.'" patternUnits="userSpaceOnUse">
                        <rect x="'.($size/2).'" y="'.($size/2).'" width="0" height="0" fill="white" transform="rotate(45 '.($size/2).' '.($size/2).')">
                            <animate attributeName="width" from="0" to="'.($size * 1.5).'" dur="'.$duration.'s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.4 0 0.2 1" begin="0s" />
                            <animate attributeName="height" from="0" to="'.($size * 1.5).'" dur="'.$duration.'s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.4 0 0.2 1" begin="0s" />
                            <animate attributeName="x" from="'.($size/2).'" to="'.(($size/2) - ($size * 0.75)).'" dur="'.$duration.'s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.4 0 0.2 1" begin="0s" />
                            <animate attributeName="y" from="'.($size/2).'" to="'.(($size/2) - ($size * 0.75)).'" dur="'.$duration.'s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.4 0 0.2 1" begin="0s" />
                        </rect>
                    </pattern>
                </defs>
                <rect x="0" y="0" width="100" height="100" fill="url(#'.$unique_id.')" />
            </svg>';

            $encoded_svg = base64_encode($svg_mask);

            $inline_css .= "
            ::view-transition-old(root) { animation: none; z-index: -1; }
            ::view-transition-new(root) {
                z-index: 1;
                -webkit-mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                -webkit-mask-size: cover;
                mask-size: cover;
                animation: snn-hold var(--snn-transition-duration) linear forwards;
            }
            @keyframes snn-hold { from { opacity: 1; } to { opacity: 1; } }
            ";
        } elseif ($transition_type === 'iris-circle') {
            // Iris: Single large circle opening from center
            // We don't use a pattern here, just a single shape
            $unique_id = 'snn_iris_' . uniqid();

            // r goes to 150 to cover corners of wide screens
            $svg_mask = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                <circle cx="50" cy="50" r="0" fill="white">
                    <animate attributeName="r" from="0" to="150" dur="'.$duration.'s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.4 0 0.2 1" begin="0s" />
                </circle>
            </svg>';

            $encoded_svg = base64_encode($svg_mask);

            $inline_css .= "
            ::view-transition-old(root) { animation: none; z-index: -1; }
            ::view-transition-new(root) {
                z-index: 1;
                -webkit-mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                -webkit-mask-size: 100% 100%;
                mask-size: 100% 100%;
                -webkit-mask-position: center;
                mask-position: center;
                -webkit-mask-repeat: no-repeat;
                mask-repeat: no-repeat;
                animation: snn-hold var(--snn-transition-duration) linear forwards;
            }
            @keyframes snn-hold { from { opacity: 1; } to { opacity: 1; } }
            ";
        } elseif ($transition_type === 'diagonal-slashes') {
            // Diagonal lines expanding
            $size = 10;
            $unique_id = 'snn_slash_' . uniqid();

            // We define a path that is a diagonal line, then increase stroke-width
            $svg_mask = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                <defs>
                    <pattern id="'.$unique_id.'" x="0" y="0" width="'.$size.'" height="'.$size.'" patternUnits="userSpaceOnUse">
                        <path d="M-1,'.$size.' L'.$size.',-1" stroke="white" stroke-width="0">
                            <animate attributeName="stroke-width" from="0" to="'.($size * 1.5).'" dur="'.$duration.'s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.4 0 0.2 1" begin="0s" />
                        </path>
                    </pattern>
                </defs>
                <rect x="0" y="0" width="100" height="100" fill="url(#'.$unique_id.')" />
            </svg>';

            $encoded_svg = base64_encode($svg_mask);

            $inline_css .= "
            ::view-transition-old(root) { animation: none; z-index: -1; }
            ::view-transition-new(root) {
                z-index: 1;
                -webkit-mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                -webkit-mask-size: cover;
                mask-size: cover;
                animation: snn-hold var(--snn-transition-duration) linear forwards;
            }
            @keyframes snn-hold { from { opacity: 1; } to { opacity: 1; } }
            ";
        } elseif ($transition_type === 'ink-spread') {
            // Ink Spread: Fractal noise pattern that expands
            $unique_id = 'snn_ink_' . uniqid();

            $svg_mask = '<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" preserveAspectRatio="none">
                <filter id="'.$unique_id.'" x="-50%" y="-50%" width="200%" height="200%">
                    <feTurbulence type="fractalNoise" baseFrequency="0.03" numOctaves="3" seed="1" result="noise" />
                    <feColorMatrix type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 25 -10" in="noise">
                        <animate attributeName="values" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 5 -25; 1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 15 -5; 1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 25 10" keyTimes="0; 0.4; 1" dur="'.$duration.'s" fill="freeze" calcMode="spline" keySplines="0.4 0 0.6 1; 0.4 0 0.2 1" />
                    </feColorMatrix>
                </filter>
                <rect width="100%" height="100%" fill="white" filter="url(#'.$unique_id.')" />
            </svg>';

            $encoded_svg = base64_encode($svg_mask);
            $inline_css .= snn_generate_mask_css($encoded_svg);
        } elseif ($transition_type === 'camera-aperture') {
            // Camera Aperture / Spiral: Concentric rings with rotation
            $svg_mask = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                <path d="M50,50 L0,0 L100,0 L50,50 Z" fill="white"><animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="'.$duration.'s" /></path>
                <circle cx="50" cy="50" r="0" fill="white">
                    <animate attributeName="r" from="0" to="100" dur="'.$duration.'s" fill="freeze" />
                </circle>
            </svg>';

            $encoded_svg = base64_encode($svg_mask);
            $inline_css .= snn_generate_mask_css($encoded_svg);
        } elseif ($transition_type === 'broken-glass') {
            // Broken Glass: Random jagged polygons using turbulence
            $unique_id = 'snn_glass_' . uniqid();

            $svg_mask = '<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" preserveAspectRatio="none">
                <filter id="'.$unique_id.'">
                    <feTurbulence type="turbulence" baseFrequency="0.05" numOctaves="2" result="noise"/>
                    <feColorMatrix type="luminanceToAlpha" in="noise" result="alphaNoise"/>
                    <feComponentTransfer>
                        <feFuncA type="linear" slope="50" intercept="-50">
                            <animate attributeName="intercept" from="-50" to="50" dur="'.$duration.'s" fill="freeze"/>
                        </feFuncA>
                    </feComponentTransfer>
                </filter>
                <rect width="100%" height="100%" fill="white" filter="url(#'.$unique_id.')" />
            </svg>';

            $encoded_svg = base64_encode($svg_mask);
            $inline_css .= snn_generate_mask_css($encoded_svg);
        } elseif ($transition_type === 'pixel-dither') {
            // Pixel Dither: Noise dissolve effect
            $unique_id = 'snn_dither_' . uniqid();

            $svg_mask = '<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" preserveAspectRatio="none">
                <filter id="'.$unique_id.'">
                    <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="1" stitchTiles="noStitch" />
                    <feColorMatrix type="saturate" values="0" />
                    <feComponentTransfer>
                        <feFuncA type="linear" slope="20" intercept="-20">
                            <animate attributeName="intercept" from="-20" to="20" dur="'.$duration.'s" fill="freeze" />
                        </feFuncA>
                    </feComponentTransfer>
                </filter>
                <rect width="100%" height="100%" fill="white" filter="url(#'.$unique_id.')" />
            </svg>';

            $encoded_svg = base64_encode($svg_mask);
            $inline_css .= snn_generate_mask_css($encoded_svg);
        } elseif ($transition_type === 'radial-wipe') {
            // Radial Wipe (Clock Sweep): A pie-shaped wedge sweeps around like a clock hand
            $inline_css .= "
            ::view-transition-old(root) {
                animation: none;
                z-index: -1;
            }
            ::view-transition-new(root) {
                animation: snn-radial-wipe var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 1;
            }

            @keyframes snn-radial-wipe {
                0%   { clip-path: polygon(50% 50%, 50% 0%, 50% 0%); }
                12.5%  { clip-path: polygon(50% 50%, 50% 0%, 100% 0%); }
                25%  { clip-path: polygon(50% 50%, 50% 0%, 100% 0%, 100% 100%); }
                37.5%  { clip-path: polygon(50% 50%, 50% 0%, 100% 0%, 100% 100%, 0% 100%); }
                50%  { clip-path: polygon(50% 50%, 50% 0%, 100% 0%, 100% 100%, 0% 100%, 0% 0%); }
                62.5%  { clip-path: polygon(50% 50%, 50% 0%, 100% 0%, 100% 100%, 0% 100%, 0% 0%, 50% 0%); }
                100% { clip-path: polygon(50% 50%, 50% 0%, 100% 0%, 100% 100%, 0% 100%, 0% 0%, 50% 0%); }
            }
            ";
        } elseif ($transition_type === 'hexagon-grid') {
            // Hexagon Grid: Hexagonal cells expanding to reveal
            $unique_id = 'snn_hex_' . uniqid();

            // Hexagonal pattern using polygon shapes in a repeating grid
            $hex_w = 12;
            $hex_h = round($hex_w * 1.1547, 2); // hex height ratio
            $half_w = $hex_w / 2;
            $quarter_h = round($hex_h / 4, 2);
            $three_quarter_h = round($hex_h * 3 / 4, 2);

            $svg_mask = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                <defs>
                    <pattern id="'.$unique_id.'" x="0" y="0" width="'.$hex_w.'" height="'.$hex_h.'" patternUnits="userSpaceOnUse">
                        <polygon points="'.$half_w.',0 '.$hex_w.','.$quarter_h.' '.$hex_w.','.$three_quarter_h.' '.$half_w.','.$hex_h.' 0,'.$three_quarter_h.' 0,'.$quarter_h.'" fill="white" transform="scale(0)" transform-origin="'.$half_w.' '.round($hex_h/2, 2).'">
                            <animateTransform attributeName="transform" type="scale" from="0" to="1.15" dur="'.$duration.'s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.4 0 0.2 1" />
                        </polygon>
                        <polygon points="'.($half_w + $half_w).','.round($hex_h/2, 2).' '.($hex_w + $half_w).','.$three_quarter_h.' '.($hex_w + $half_w).','.round($hex_h + $quarter_h, 2).' '.($half_w + $half_w).','.round($hex_h + round($hex_h/2, 2), 2).' '.$half_w.','.round($hex_h + $quarter_h, 2).' '.$half_w.','.$three_quarter_h.'" fill="white" transform="scale(0)" transform-origin="'.$hex_w.' '.round($hex_h * 0.75, 2).'">
                            <animateTransform attributeName="transform" type="scale" from="0" to="1.15" dur="'.$duration.'s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.4 0 0.2 1" />
                        </polygon>
                    </pattern>
                </defs>
                <rect x="0" y="0" width="100" height="100" fill="url(#'.$unique_id.')" />
            </svg>';

            $encoded_svg = base64_encode($svg_mask);

            $inline_css .= "
            ::view-transition-old(root) { animation: none; z-index: -1; }
            ::view-transition-new(root) {
                z-index: 1;
                -webkit-mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                mask-image: url('data:image/svg+xml;base64," . $encoded_svg . "');
                -webkit-mask-size: cover;
                mask-size: cover;
                animation: snn-hold var(--snn-transition-duration) linear forwards;
            }
            @keyframes snn-hold { from { opacity: 1; } to { opacity: 1; } }
            ";
        } elseif ($transition_type === 'zoom-scale') {
            // Zoom Scale: Old page zooms out and fades, new page zooms in from large
            $inline_css .= "
            ::view-transition-old(root) {
                animation: snn-zoom-out var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 1;
            }
            ::view-transition-new(root) {
                animation: snn-zoom-in var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 2;
            }

            @keyframes snn-zoom-out {
                0% {
                    transform: scale(1);
                    opacity: 1;
                }
                100% {
                    transform: scale(0.5);
                    opacity: 0;
                }
            }

            @keyframes snn-zoom-in {
                0% {
                    transform: scale(1.5);
                    opacity: 0;
                }
                100% {
                    transform: scale(1);
                    opacity: 1;
                }
            }

            ::view-transition-image-pair(root) { isolation: isolate; }
            ";
        } elseif ($transition_type === 'zoom-in-scale') {
            // Zoom In Scale: Old page zooms in (grows) and fades, new page scales up from small
            $inline_css .= "
            ::view-transition-old(root) {
                animation: snn-zoom-in-out var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 1;
            }
            ::view-transition-new(root) {
                animation: snn-zoom-in-in var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 2;
            }

            @keyframes snn-zoom-in-out {
                0% {
                    transform: scale(1);
                    opacity: 1;
                }
                100% {
                    transform: scale(1.5);
                    opacity: 0;
                }
            }

            @keyframes snn-zoom-in-in {
                0% {
                    transform: scale(0.5);
                    opacity: 0;
                }
                100% {
                    transform: scale(1);
                    opacity: 1;
                }
            }

            ::view-transition-image-pair(root) { isolation: isolate; }
            ";
        } elseif ($transition_type === 'slide-push') {
            // Slide Push: Old page pushes out left while new page pushes in from right (carousel effect)
            $inline_css .= "
            ::view-transition-old(root) {
                animation: snn-slide-push-out var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 1;
            }
            ::view-transition-new(root) {
                animation: snn-slide-push-in var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 2;
            }

            @keyframes snn-slide-push-out {
                from { transform: translateX(0); }
                to { transform: translateX(-100%); }
            }

            @keyframes snn-slide-push-in {
                from { transform: translateX(100%); }
                to { transform: translateX(0); }
            }

            ::view-transition-image-pair(root) { isolation: isolate; }
            ";
        } elseif ($transition_type === 'slide-over') {
            // Slide Over: New page slides in from right on top, old page stays or slightly scales down (iOS style)
            $inline_css .= "
            ::view-transition-old(root) {
                animation: snn-slide-over-old var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 1;
            }
            ::view-transition-new(root) {
                animation: snn-slide-over-new var(--snn-transition-duration) cubic-bezier(0.4, 0, 0.2, 1) both;
                z-index: 2;
            }

            @keyframes snn-slide-over-old {
                from {
                    transform: scale(1) translateX(0);
                    opacity: 1;
                }
                to {
                    transform: scale(0.95) translateX(-10%);
                    opacity: 0.5;
                }
            }

            @keyframes snn-slide-over-new {
                from { transform: translateX(100%); }
                to { transform: translateX(0); }
            }

            ::view-transition-image-pair(root) { isolation: isolate; }
            ";
        } elseif ($transition_type === 'random-mosaic-peel') {
            // Random Mosaic Peel: JS-driven, page splits into a grid and each square
            // peels away in a random staggered order to reveal the new page.
            // Disable native view transition — JavaScript handles everything.
            $inline_css = "
            .snn-mosaic-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                overflow: hidden;
                pointer-events: none;
                z-index: 2147483647;
            }
            .snn-mosaic-sq {
                position: absolute;
                background: #111;
                transform-origin: center;
                will-change: transform, opacity;
            }
            ";

            $sq_size = 60;
            $sq_dur  = min(0.45, $duration * 0.4);

            $inline_js = "
(function() {
    if (new URLSearchParams(window.location.search).get('bricks') === 'run') return;

    var TOTAL = " . $duration . ";
    var SZ    = " . $sq_size . ";
    var SQDUR = " . $sq_dur . ";
    var busy  = false;

    function shuffle(a) {
        for (var i = a.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));
            var t = a[i]; a[i] = a[j]; a[j] = t;
        }
    }

    function buildOverlay(mode) {
        var cols  = Math.ceil(window.innerWidth  / SZ) + 1;
        var rows  = Math.ceil(window.innerHeight / SZ) + 1;
        var total = cols * rows;
        var stagger = Math.max(0, TOTAL - SQDUR);

        var order = [];
        for (var n = 0; n < total; n++) order.push(n);
        shuffle(order);

        var ov   = document.createElement('div');
        ov.className = 'snn-mosaic-overlay';
        ov.setAttribute('aria-hidden', 'true');

        var frag = document.createDocumentFragment();
        var sqs  = [];

        for (var i = 0; i < total; i++) {
            var idx   = order[i];
            var r     = Math.floor(idx / cols);
            var c     = idx % cols;
            var delay = (i / total) * stagger;

            var sq = document.createElement('div');
            sq.className = 'snn-mosaic-sq';
            sq.style.left   = (c * SZ) + 'px';
            sq.style.top    = (r * SZ) + 'px';
            sq.style.width  = SZ + 'px';
            sq.style.height = SZ + 'px';

            if (mode === 'cover') {
                sq.style.transform  = 'scale(0)';
                sq.style.opacity    = '0';
                sq.style.transition =
                    'transform ' + SQDUR + 's cubic-bezier(0.2,0,0.2,1) ' + delay + 's,' +
                    'opacity '   + (SQDUR * 0.25) + 's linear ' + delay + 's';
            } else {
                sq.style.transform  = 'scale(1)';
                sq.style.opacity    = '1';
                sq.style.transition =
                    'transform ' + SQDUR + 's cubic-bezier(0.2,0,0.2,1) ' + delay + 's,' +
                    'opacity '   + (SQDUR * 0.25) + 's linear ' + (delay + SQDUR * 0.75) + 's';
            }
            sqs.push(sq);
            frag.appendChild(sq);
        }
        ov.appendChild(frag);
        ov._sq = sqs;
        return ov;
    }

    function fire(ov, mode) {
        ov._sq.forEach(function(sq) {
            if (mode === 'cover') {
                sq.style.transform = 'scale(1)';
                sq.style.opacity   = '1';
            } else {
                sq.style.transform = 'scale(0)';
                sq.style.opacity   = '0';
            }
        });
    }

    // Entry: uncover new page
    if (sessionStorage.getItem('snn_mp')) {
        sessionStorage.removeItem('snn_mp');
        var ov = buildOverlay('uncover');
        document.body.appendChild(ov);
        requestAnimationFrame(function() {
            requestAnimationFrame(function() {
                fire(ov, 'uncover');
                setTimeout(function() {
                    if (ov.parentNode) ov.parentNode.removeChild(ov);
                }, (TOTAL + 0.3) * 1000);
            });
        });
    }

    // Exit: cover old page then navigate
    document.addEventListener('click', function(e) {
        if (busy) return;
        var link = e.target.closest ? e.target.closest('a') : (function() {
            var el = e.target;
            while (el && el.tagName !== 'A') el = el.parentNode;
            return el && el.tagName === 'A' ? el : null;
        }());
        if (!link) return;

        var href = link.getAttribute('href');
        if (!href) return;
        if (link.getAttribute('target') === '_blank') return;
        if (/^[#?]|^(mailto|tel|javascript):/.test(href.trim())) return;

        var dest;
        try { dest = new URL(href, location.href); } catch(x) { return; }
        if (dest.origin !== location.origin) return;
        if (/\/wp-admin\//.test(dest.pathname)) return;

        e.preventDefault();
        busy = true;

        var ov = buildOverlay('cover');
        document.body.appendChild(ov);
        requestAnimationFrame(function() {
            requestAnimationFrame(function() { fire(ov, 'cover'); });
        });

        sessionStorage.setItem('snn_mp', '1');
        setTimeout(function() { location.href = dest.href; }, (TOTAL + 0.05) * 1000);
    }, true);
})();
            ";

            wp_register_script('snn-mosaic-peel', false, [], null, true);
            wp_enqueue_script('snn-mosaic-peel');
            wp_add_inline_script('snn-mosaic-peel', $inline_js);

        } else {
            // Fade: Smooth Crossfade
            // mix-blend-mode: plus-lighter prevents the white background from bleeding through
            $inline_css .= "
            ::view-transition-old(root) {
                animation: snn-fade-out var(--snn-transition-duration) ease both;
            }
            ::view-transition-new(root) {
                animation: snn-fade-in var(--snn-transition-duration) ease both;
                mix-blend-mode: plus-lighter;
            }

            @keyframes snn-fade-out { from { opacity: 1; } to { opacity: 0; } }
            @keyframes snn-fade-in { from { opacity: 0; } to { opacity: 1; } }

            /* Fallback for dark mode/specific blending issues */
            ::view-transition-image-pair(root) { isolation: isolate; }
            ";
        }

        // CSS-only - no JavaScript needed for native MPA transitions!
        wp_register_style('snn-view-transitions', false);
        wp_enqueue_style('snn-view-transitions');
        wp_add_inline_style('snn-view-transitions', $inline_css);
    }
}
add_action('wp_enqueue_scripts', 'snn_enqueue_page_transitions');


